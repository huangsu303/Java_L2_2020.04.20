package com.lagou.test;

import com.lagou.dao.IUserDao;
import com.lagou.io.Resources;
import com.lagou.pojo.User;
import com.lagou.sqlSession.SqlSession;
import com.lagou.sqlSession.SqlSessionFactory;
import com.lagou.sqlSession.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

public class IPersistenceTest {
    @Test
    public void test() throws Exception{
        InputStream resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        // 调用
        User user = new User();
        user.setId(1);
        user.setUsername("张三");
//        User user2 = sqlSession.selectOne("user.selectOne",user);
//        System.out.println(user2);

//        List<User> users = sqlSession.selectList("user.selectList");
//        for(User user1:users){
//            System.out.println(user1);
//        }
        IUserDao userDao = sqlSession.getMapper(IUserDao.class);
        //User user2 = userDao.findByCondition(user);
        List<User> all = userDao.findAll();
        for(User user1:all){
            System.out.println(user1);
        }
    }

    @Test
    public void testInsert() throws Exception{
        InputStream resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        // 调用
        User user = new User();
        user.setId(11);
        user.setUsername("lisi");
        IUserDao userDao = sqlSession.getMapper(IUserDao.class);
        int count = userDao.addUser(user);

        System.out.println(count);
    }

    @Test
    public void testUpdate() throws Exception{
        InputStream resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        // 调用
        User user = new User();
        user.setId(11);
        user.setUsername("wangwu");
        IUserDao userDao = sqlSession.getMapper(IUserDao.class);
        int count = userDao.updateUser(user);

        System.out.println(count);
    }

    @Test
    public void testDelete() throws Exception{
        InputStream resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        // 调用
        User user = new User();
        user.setId(11);
        IUserDao userDao = sqlSession.getMapper(IUserDao.class);
        int count = userDao.deleteUser(user);

        System.out.println(count);
    }
}
